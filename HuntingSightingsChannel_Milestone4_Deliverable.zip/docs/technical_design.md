# Hunting Sightings Channel - Technical Design Document

## System Architecture

### Overview
The Hunting Sightings Channel is an automated system that extracts wildlife sighting mentions from multiple sources and maps them to Colorado Game Management Units (GMUs) for hunter intelligence.

### Tech Stack
- **Language**: Python 3.11
- **Geospatial**: GeoPandas, Shapely (point-in-polygon operations)
- **HTTP**: Requests (API calls with proper User-Agent)
- **Data Processing**: Pandas, JSON
- **Logging**: Loguru
- **CLI**: Rich (terminal UI)

### Core Components

1. **Web Scrapers**
 - Base scraper class with rate limiting and error handling
 - Source-specific scrapers:
 - 14ers.com (trip reports)
 - SummitPost.org (route descriptions)
 - Reddit (r/Hunting, r/COhunting, etc.)
 - iNaturalist (verified wildlife observations)
 - OpenStreetMap (trail/peak locations via Overpass API)

2. **Geospatial Processing**
 - GMU polygon management using GeoPandas
 - Point-in-polygon queries for location → GMU mapping
 - Complete Colorado GMU dataset (185 units, 25.7MB GeoJSON)
 - Trail/peak index with pre-computed GMU mappings

3. **Data Storage**
 - File-based storage (JSON, CSV)
 - Structured directories:
 - `data/gmu/` - GMU boundary polygons
 - `data/trails/` - Trail/peak indices
 - `data/sightings/` - Wildlife observations
 - `data/raw/` - Cached API responses

4. **Processing Pipeline**
 - Extract sightings from sources
 - Geocode locations (trail names → coordinates)
 - Map coordinates to GMUs
 - Validate with LLM (when API key available)
 - Generate structured output

## API Rate Limits and Compliance

### iNaturalist API
- **Rate limit**: 10,000 requests/day (well within limits)
- **Authentication**: None required for public data
- **Compliance**: Using research-grade observations only
- **User-Agent**: Identifies bot and contact

### OpenStreetMap (Overpass API)
- **Rate limit**: 1 request/second
- **Query timeout**: 20 minutes for large datasets
- **User-Agent**: "Hunting-Sightings-Channel/1.0 (contact@example.com)"
- **Caching**: Raw JSON cached to avoid repeated API hits
- **Alternative endpoint**: overpass.kumi.systems if main throttles

### Reddit API
- **Authentication**: OAuth2 with script app
- **Rate limit**: 60 requests/minute
- **Compliance**: Full API terms compliance
- **Caching**: 24-hour cache for efficiency

### 14ers.com
- **Rate limit**: 1 request/second
- **Robots.txt**: Respected
- **User-Agent**: Identifies bot purpose

### SummitPost.org
- **Rate limit**: 0.5 requests/second (conservative)
- **HTML parsing**: No official API
- **Robots.txt**: Respected

## Terms of Service Compliance

### Current Status (June 2025)
- **14ers.com**: Allows non-commercial crawling with rate limits
- **SummitPost**: Public content, rate-limited access OK
- **Reddit**: Official API with OAuth compliance
- **iNaturalist**: CC-licensed data, API encouraged
- **OpenStreetMap**: ODbL license, proper attribution required

### Best Practices
- Bot identification in all User-Agent headers
- Contact information provided
- Rate limiting below stated limits
- No personal data collection
- Public content only

## Point-in-Polygon Method

### GMU Mapping Process
1. **Load GMU polygons**: 185 Colorado GMUs from CPW GeoJSON
2. **Convert coordinates**: Ensure WGS84 (EPSG:4326) projection
3. **Spatial query**: Use Shapely's `contains()` for point-in-polygon
4. **Performance**: ~50ms per lookup, 25 seconds for 17,000 points

### Trail Index Benefits
- **Pre-computed mappings**: Avoid repeated GMU lookups
- **Name resolution**: "Lost Creek Trail" → coordinates → GMU
- **Coverage**: 17,512 trails/peaks mapped to GMUs
- **Efficiency**: CSV index enables instant lookups

## Data Flow Example

```
User Query: "Bear sightings near Mount Elbert"
 ↓
1. Trail Index: "Mount Elbert" → (39.1178, -106.4454)
 ↓
2. GMU Processor: Coordinates → GMU 48
 ↓
3. Scraper: Search sources for "bear" + "GMU 48" area
 ↓
4. LLM Validator: Confirm true sightings (if API available)
 ↓
5. Output: Structured sighting data with GMU location
```

## Milestone Roadmap

### Milestone 1 (Complete)
- GMU processor with full Colorado dataset
- Trail/peak index via OSM (17,512 features)
- Base scrapers for 5 sources
- iNaturalist integration
- Reddit API connection

### Milestone 2 (Next)
- PostgreSQL with PostGIS integration
- Enhanced location extraction
- Historical data analysis
- Basic web interface

### Milestone 3
- Email digest system
- User preferences (GMU filtering)
- Automated scheduling
- Alert notifications

### Milestone 4
- Machine learning for sighting validation
- Trail camera integration
- Mobile app API
- Advanced analytics dashboard

## Performance Metrics

- **OSM data pull**: 18 seconds for 60,909 elements
- **GMU mapping**: 25 seconds for 17,512 points
- **iNaturalist query**: 10 seconds for 9 species
- **Reddit scraping**: 2-3 seconds per subreddit
- **Total pipeline**: <2 minutes for full refresh

## Security Considerations

- API keys in environment variables
- No storage of user personal data
- Read-only web scraping
- Cached data in .gitignore

## Future Enhancements

1. **Real-time processing**: WebSocket for instant updates
2. **Multi-state support**: Expand beyond Colorado
3. **AI sighting validation**: GPT-4 for better filtering
4. **Community features**: Hunter-submitted reports
5. **Predictive analytics**: Migration pattern forecasting
