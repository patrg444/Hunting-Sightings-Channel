# Milestone 3: Email Digest System Deliverable

## Overview
This package contains the complete email digest system for the Wildlife Sightings Channel. The system generates beautiful HTML emails with daily wildlife sighting summaries and includes automation scripts for scheduled delivery.

## What's Included

### 1. Email Template
- `templates/email_digest.html` - Responsive HTML email template
  - Professional design with wildlife theme
  - Shows sightings by species, location, and GMU
  - Mobile-friendly layout

### 2. Email Sending Script
- `scripts/send_email_digest.py` - Main email generation and sending script
  - Generates emails from sighting data
  - Preview mode for testing
  - SMTP integration
  - Jinja2 templating

### 3. Automation Scripts
- `scripts/setup_cron.sh` - Sets up daily cron job (6 AM)
- `scripts/test_full_pipeline.sh` - Tests entire pipeline end-to-end

### 4. Sample Output
- `data/email_preview.html` - Example of generated email

## Setup Instructions

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Email Settings
```bash
cp .env.example .env
# Edit .env with your email settings:
# EMAIL_FROM=your-email@gmail.com
# EMAIL_TO=recipient@example.com
# EMAIL_PASSWORD=your-app-password (for Gmail)
# SMTP_SERVER=smtp.gmail.com
# SMTP_PORT=587
```

### 3. Test Email Preview
```bash
# Generate preview without sending
python scripts/send_email_digest.py --test
# View the preview at: data/email_preview.html
```

### 4. Send Test Email
```bash
# Send actual email
python scripts/send_email_digest.py
```

### 5. Set Up Daily Automation
```bash
# Run the cron setup script
./scripts/setup_cron.sh
# This will schedule daily emails at 6 AM
```

### 6. Test Full Pipeline
```bash
# Test everything end-to-end
./scripts/test_full_pipeline.sh
```

## Email Features
- Daily digest of wildlife sightings
- Organized by species and location
- GMU mapping included
- Links to source content
- Summary statistics
- Unsubscribe options

## SMTP Configuration Notes
- For Gmail: Use App Password (not regular password)
- Enable 2FA and generate app-specific password
- Other providers: Check their SMTP settings

## Customization
- Edit `templates/email_digest.html` for design changes
- Modify send time in `setup_cron.sh`
- Add recipients in `.env` file
